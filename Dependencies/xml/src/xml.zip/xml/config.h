#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#define LINUX 1

#endif // CONFIG_H_INCLUDED
