package com.turboirc.xml;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;




import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.R.string;
import android.annotation.TargetApi;
import android.os.Build;
import android.text.TextUtils;
import android.util.Base64;

import java.io.ByteArrayInputStream;

public class XML {
	
	String FileName = null;
	InputStream wf = null;
	XMLElement root = new XMLElement(null,"root");

	private static int iv(String x)
		{
			int i = 0;
			if (x == null)
				return i;
			try 
			{
				i = Integer.valueOf(x);
			}
			catch(Throwable ex)
			{
			}
			return i;
		}
	private static long lv(String x)
		{
			long i = 0;
			if (x == null)
				return i;
			try 
			{
				i = Long.valueOf(x);
			}
			catch(Throwable ex)
			{
			}
			return i;
		}


	public static String XMLEncode(String s)
		{
		// org.apache.commons.lang.StringEscapeUtils;
		/*String[] sources1 = {"&"};
		String[] dests1 = {"----AMP----"};

		String[] sources = {">","<","\"","'"};
		String[] dests = {"&gt;","&lt;","&quot;","&apos;"};
		*/
		return s.replace("&", "&amp;").replace(">", "&gt;").replace("<", "&lt;").replace("\"", "&quot;").replace("'", "&apos;");
		
///		s = TextUtils.replace(s, sources,dests).toString();
	//	return s;
		
		/*
		// Encodes the value from v to &v
		String ss = new String();
		int len = s.length();
		for(int i = 0 ; i < len ; i++)
			{
			char b1 = s.charAt(i);
			char b2 = ' ';
			if (i < (len - 1))
				b2 = s.charAt(i + 1);
			
			if (b1 == '&' && b2 != '#')
				{
				ss += "&amp;";
				}
			else
			if (b1 == '>')
				{
				ss += "&gt;";
				}
			else
			if (b1 == '<')
				{
				ss += "&lt;";
				}
			else
			if (b1 == '"')
				{
				ss += "&quot;";
				}
			else
			if (b1 == '\'')
				{
				ss += "&apos;";
				}
			else
				{
				ss += b1;
				}
			}
		
//		String ss = new String(s);
		return ss;
	*/
		}

	
	public static String XMLDecode(String s)
		{
		return s.replace("&amp;", "&").replace("&gt;",">").replace( "&lt;","<").replace( "&quot;","\"").replace( "&apos;","'");

//		String ss = new String(s);
//		return ss;
		}
	
	public XML(String fn)
		{
		FileName= new String(fn);
		try 
			{
			wf = (InputStream)new FileInputStream(FileName);
			Parse();
			} 
		catch (Throwable e) 
			{
			}
		}
	
	static public XML FromString(String str)
		{
		if (str == null)
			return null;
		
        InputStream is = new ByteArrayInputStream(str.getBytes());
        XML xu = new XML(is);
		return xu;
		}
	
	public XML(InputStream wx)
		{
		FileName = new String("");
		wf = wx;
		try 
			{
			Parse();
			} 
		catch (Throwable e) 
			{
			} 
		}
	
	public String Serialize()
		{
		String s = new String("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n");
		return s.concat(root.Serialize());
		}
	
	
	public XMLElement GetRootElement()
		{
		return root;
		}
	
	public boolean Save(String fn)
		{
		String s = Serialize();
		try 
			{
			FileOutputStream fout = null;
			fout = new FileOutputStream(fn);
			PrintStream wf = new PrintStream(fout);
			
			wf.print(s);
			wf.close();
			}
		catch(Throwable ex)
			{
			return false;
			}
		return true;
		}
	
	
	static public class XMLHeader
		{
		}
	
	static public class XMLElement
		{
		private String name = null;
		private XMLElement Parent = null;
		private ArrayList<XMLVariable> Variables = null;
		private ArrayList<XMLElement> Children = null;
		private ArrayList<XMLComment> Comments = null;
		private ArrayList<XMLContent> Contents = null;
		private ArrayList<XMLCData> CDatas = null;
		
		
		public void SetRParent(XMLElement cc)
			{
			Parent = cc;
			for(int i = 0 ; i < Variables.size() ; i++)
				Variables.get(i).Parent = this;
			for(int i = 0 ; i < Comments.size() ; i++)
				Comments.get(i).Parent = this;
			for(int i = 0 ; i < Contents.size() ; i++)
				Contents.get(i).Parent = this;
			for(int i = 0 ; i < CDatas.size() ; i++)
				CDatas.get(i).Parent = this;
			
			for(int i = 0 ; i < Children.size() ; i++)
				{
				Children.get(i).Parent = this;
				Children.get(i).SetRParent(this);
				}
			}
		
		public XMLElement Duplicate(XMLElement ToParent)
			{
			XMLElement nx = new XMLElement(Parent);
			nx.name = new String(name);
			
			nx.Variables = new ArrayList<XMLVariable>(Variables);
			for(int i = 0 ; i < nx.Variables.size() ; i++)
				nx.Variables.set(i, nx.Variables.get(i).Duplicate());
			
			nx.Comments = new ArrayList<XMLComment>(Comments);
			for(int i = 0 ; i < nx.Comments.size() ; i++)
				nx.Comments.set(i, nx.Comments.get(i).Duplicate());

			nx.Contents = new ArrayList<XMLContent>(Contents);
			for(int i = 0 ; i < nx.Contents.size() ; i++)
				nx.Contents.set(i, nx.Contents.get(i).Duplicate());

			nx.CDatas = new ArrayList<XMLCData>(CDatas);
			for(int i = 0 ; i < nx.CDatas.size() ; i++)
				nx.CDatas.set(i, nx.CDatas.get(i).Duplicate());

			nx.Children = new ArrayList<XMLElement>(Children);
			for(int i = 0 ; i < nx.Children.size() ; i++)
				nx.Children.set(i, nx.Children.get(i).Duplicate(null));

			nx.SetRParent(ToParent);
			return nx;
			}
		
		public int GetDeepLevel()
			{
			if (Parent == null)
				return 0;
			return Parent.GetDeepLevel() + 1;
			}
		
		public String GetDeepLevelString()
			{
			String a = new String("");
			int dl = GetDeepLevel();
			for(int i = 0 ; i < dl ; i++)
				{
				a += ("\t");
				}
			return a;
			}
		
		public XMLElement ReplaceElement(int i,XMLElement y)
			{
			if (y == null)
				return null;
			if (i >= Children.size())
				return null;
			y.Parent = this;
			y.SetRParent(this);
			Children.set(i, y);
			return y;
			}
		
		public boolean RemoveElement(XMLElement y)
			{
			for(int i = 0 ; i < Children.size() ; i++)
				{
				if (Children.get(i) == y)
					{
					Children.remove(i);
					return true;
					}
				}
			return false;
			}

		public boolean Discard()
			{
			XMLElement p = GetParent();
			if (p == null)
				return false;
			p.RemoveElement(this);
			return true;
			}
		
		
		public XMLElement AddElement(String a)
			{
			XMLElement y = new XMLElement(this,a);
			y.Parent = this;
			y.SetRParent(this);
			Children.add(y);
			return y;
			}

		public XMLElement AddElement(XMLElement y)
			{
			if (y == null)
				return null;
			y.Parent = this;
			y.SetRParent(this);
			Children.add(y);
			return y;
			}
		public XMLElement AddElement(XMLElement y,int idx)
			{
			if (y == null)
				return null;
			y.Parent = this;
			y.SetRParent(this);
			Children.add(idx,y);
			return y;
			}
		
		public XMLVariable AddVariable(XMLVariable y)
			{
			if (y == null)
				return null;
			y.Parent = this;
			Variables.add(y);
			return y;
			}
		public XMLVariable AddVariable(XMLVariable y,int idx)
			{
			if (y == null)
				return null;
			y.Parent = this;
			Variables.add(idx,y);
			return y;
			}
		
		public XMLVariable AddVariable(String n,String v)
			{
			if (n == null || v == null)
				return null;
			XMLVariable y = new XMLVariable(null,n,v);
			y.Parent = this;
			Variables.add(y);
			return y;
			}

		public XMLContent AddContent(XMLContent y)
			{
			if (y == null)
				return null;
			y.Parent = this;
			Contents.add(y);
			return y;
			}
		public XMLContent AddContent(XMLContent y,int idx)
			{
			if (y == null)
				return null;
			y.Parent = this;
			Contents.add(idx,y);
			return y;
			}
		
		public XMLContent AddContent(String v)
			{
			if (v == null)
				return null;
			XMLContent y = new XMLContent(null,v,0);
			y.Parent = this;
			Contents.add(y);
			return y;
			}
		
		public XMLCData AddCData(XMLCData y)
			{
			if (y == null)
				return null;
			y.Parent = this;
			CDatas.add(y);
			return y;
			}
		public XMLCData AddCData(XMLCData y,int idx)
			{
			if (y == null)
				return null;
			y.Parent = this;
			CDatas.add(idx,y);
			return y;
			}
		public XMLCData AddCData(String v)
			{
			if (v == null)
				return null;
			XMLCData y = new XMLCData(null,v,0);
			y.Parent = this;
			CDatas.add(y);
			return y;
			}		
		
		
		
		public int GetAllChildrenNum()
			{
			int nc = GetChildrenNum();
			for(int i = 0 ; i < GetChildren().size() ; i++)
				{
				nc += GetChildren().get(i).GetAllChildrenNum();
				}
			return nc;
			}
		
		public ArrayList<XMLElement> GetAllChildren(ArrayList<XMLElement> cc)
			{
			for(int i = 0 ; i < GetChildren().size() ; i++)
				{
				cc.add(GetChildren().get(i));
				GetChildren().get(i).GetAllChildren(cc);
				}
			return cc;
			}
		
		
		public int GetChildrenNum()
			{
			return Children.size();
			}
		
		public ArrayList<XMLElement> GetChildren()
			{
			return Children;
			}
		public ArrayList<XMLVariable> GetVariables()
			{
			return Variables;
			}
		public ArrayList<XMLComment> GetComments()
			{
			return Comments;
			}
		public ArrayList<XMLContent> GetContents()
			{
			return Contents;
			}
		public String GetContent()
			{
			if (Contents == null) return "";
			if (Contents.size() == 0) return "";
			return Contents.get(0).GetValue();
			}
		public void SetContent(String v)
			{
			if (Contents.size() == 0)
				Contents.add(new XMLContent(this, v, 0)); 
			else
				Contents.get(0).value = v;
			}
		
		
		public XMLVariable SetValue(String vv,String val)
			{
			XMLVariable v = FindVariableZ(vv,false,true);
			v.SetValue(val);
			return v;
			}

		public String VariableValue(String v)
			{
			return VariableValue(v,"");
			}

		public String VariableValue(String v,String def)
			{
			if (FindVariableZ(v, false, false) == null)
				return def;
			
			XMLVariable vv = FindVariableZ(v, false, true);
			return vv.GetValue();
			}
		
		
		public ArrayList<XMLCData> GetCDatas()
			{
			return CDatas;
			}

		public String GetName()
			{
			return new String(name);
			}
		public XMLElement Parent()
			{
			return Parent;
			}
		
		public XMLElement(XMLElement P)
			{
			Parent = P;
			name = new String("e");
			Variables = new ArrayList<XMLVariable>(0);
			Children = new ArrayList<XMLElement>(0);
			Comments = new ArrayList<XMLComment>(0);
			Contents = new ArrayList<XMLContent>(0);
			CDatas = new ArrayList<XMLCData>(0);
			}
		public XMLElement(XMLElement P,String n)
			{
			Parent = P;
			name = new String(n);
			Variables = new ArrayList<XMLVariable>(0);
			Children = new ArrayList<XMLElement>(0);
			Comments = new ArrayList<XMLComment>(0);
			Contents = new ArrayList<XMLContent>(0);
			CDatas = new ArrayList<XMLCData>(0);
			}

		
		public void SetName(String s)
			{
			if (s != null)
				name = new String(s);
			}
		
		public XMLElement GetParent()
			{
			return Parent;
			}
		
		public XMLElement Next()
			{
			XMLElement p = GetParent();
			if (p == null)
				return null;
			int npx = p.GetChildrenNum();
			for(int i = 0 ; i < (npx - 1) ; i++)
				{
				if (p.GetChildren().get(i) == this)
					return p.GetChildren().get(i + 1);
				}
			return null;
			}
		
		public XMLElement Prev()
			{
			XMLElement p = GetParent();
			if (p == null)
				return null;
			int npx = p.GetChildrenNum();
			for(int i = 1 ; i < npx ; i++)
				{
				if (p.GetChildren().get(i) == this)
					return p.GetChildren().get(i - 1);
				}
			return null;
			}

		public XMLElement el(String n)
			{
			return FindElementZ(n,false,true);
			}

		public XMLElement ifel(String n)
			{
			return FindElementZ(n,false,false);
			}

		public XMLElement FindElementZ(String n,boolean CreateIfNot)
			{
			return FindElementZ(n,false,CreateIfNot);
			}

		
		public int FindElement(XMLElement e)
			{
			for(int i = 0 ; i < Children.size() ; i++)
				{
				if (Children.get(i) == e)
					return i;
				}
			return -1;
			}
		
		public XMLElement FindElementZ(String n,boolean Case,boolean CreateIfNot)
			{
			for(int i = 0 ; i < Children.size() ; i++)
				{
				if (Case)
					{
					if (Children.get(i).GetName().equals(n))
						return Children.get(i);
					}
				else
					{
					if (Children.get(i).GetName().equalsIgnoreCase(n))
						return Children.get(i);
					}
				}
			if (CreateIfNot == false)
				return null;

			XMLElement e = new XMLElement(this);
			e.SetName(n);
			Children.add(e);
			return Children.get(Children.size() - 1);
			}
		
		public XMLVariable FindVariableZ(String n,boolean c)
			{
			return FindVariableZ(n, false, c);
			}

		public XMLVariable FindVariableZ(String n,boolean Case,boolean CreateIfNot)
			{
			for(int i = 0 ; i < Variables.size() ; i++)
				{
				if (Case)
					{
					if (Variables.get(i).GetName().equals(n))
						return Variables.get(i);
					}
				else
					{
					if (Variables.get(i).GetName().equalsIgnoreCase(n))
						return Variables.get(i);
					}
				}
			if (CreateIfNot == false)
				return null;

			XMLVariable e = new XMLVariable(this,n,"");
			Variables.add(e);
			return Variables.get(Variables.size() - 1);
			}		
		
		public String Serialize()
			{
			String s = null;
			
			if (Children.size() == 0 && Comments.size() == 0 && CDatas.size() == 0 && Contents.size() == 0)
				{
				// We will create a <text x y z />
				String AllVars = new String("");
				for(int i = 0 ; i < Variables.size() ; i++)
					{
					XMLVariable v = Variables.get(i);
					String x = v.Serialize();
					AllVars += x;
					AllVars += " ";
					}
				
				if (AllVars.length() > 1)
					s = String.format("%s<%s %s />\r\n",GetDeepLevelString(),name,AllVars);
				else
					s = String.format("%s<%s/>\r\n",GetDeepLevelString(),name);
				}
			else
				{
				// We will create a <text x y z >
				String AllVars = new String("");
				for(int i = 0 ; i < Variables.size() ; i++)
					{
					XMLVariable v = Variables.get(i);
					String x = v.Serialize();
					AllVars += x;
					AllVars += " ";
					}
				
				
				if (AllVars.length() > 1)
					s = String.format("%s<%s %s>\r\n",GetDeepLevelString(),name,AllVars);
				else
					s = String.format("%s<%s>\r\n",GetDeepLevelString(),name,AllVars);
				
				// All Children
				for(int i = 0 ; i < Children.size() ; i++)
					{
					// Check comments,cdatas,text before those
					for(int y = 0 ; y < Comments.size() ; y++)
						{
						XMLComment c = Comments.get(y);
						if (c.GetBE() != i)
							continue;
						
						String u = c.Serialize();
						s += String.format("%s%s\r\n",GetDeepLevelString(),u);
						}
					for(int y = 0 ; y < CDatas.size() ; y++)
						{
						XMLCData c = CDatas.get(y);
						if (c.GetBE() != i)
							continue;
						
						String u = c.Serialize();
						s += String.format("%s%s\r\n",GetDeepLevelString(),u);
						}
					for(int y = 0 ; y < Contents.size() ; y++)
						{
						XMLContent c = Contents.get(y);
						if (c.GetBE() != i)
							continue;
						
						String u = c.Serialize();
						s += String.format("%s%s\r\n",GetDeepLevelString(),u);
						}
					
					XMLElement ch = Children.get(i);
					String u = ch.Serialize();
					s += String.format("%s",u);
					}
				
				// Shoot remaining stuff
				for(int y = 0 ; y < Comments.size() ; y++)
					{
					XMLComment c = Comments.get(y);
					if (c.GetBE() < Children.size())
						continue;
					
					String u = c.Serialize();
					s += String.format("%s%s\r\n",GetDeepLevelString(),u);
					}
				for(int y = 0 ; y < CDatas.size() ; y++)
					{
					XMLCData c = CDatas.get(y);
					if (c.GetBE() < Children.size())
						continue;
						
					String u = c.Serialize();
					s += String.format("%s%s\r\n",GetDeepLevelString(),u);
					}
				for(int y = 0 ; y < Contents.size() ; y++)
					{
					XMLContent c = Contents.get(y);
					if (c.GetBE() < Children.size())
						continue;
					
					String u = c.Serialize();
					s += String.format("%s%s\r\n",GetDeepLevelString(),u);
					}
				
				// End
				s += String.format("%s</%s>\r\n",GetDeepLevelString(),name);
				}
			return s;
			}
		
		public byte[] Encrypt(String pwd)
			{
			try
				{
				if (pwd == null)
					return null;

				// Get this element in a string
				String s = Serialize();
				if (s == null)
					return null;
				
				// SHA-1 the password
				MessageDigest sha = MessageDigest.getInstance("SHA-1");
				byte[] key = sha.digest(pwd.getBytes());
				key = Arrays.copyOf(key, 32); // use only first 128 bit
				
				SecretKeySpec sks = new SecretKeySpec(key, "AES");
				
				 // Instantiate the cipher
			    Cipher cipher = Cipher.getInstance("AES");
			    cipher.init(Cipher.ENCRYPT_MODE, sks);

			    byte[] encrypted = cipher.doFinal(s.getBytes());
				return encrypted;
				}
			catch(Throwable ex)
				{
				ex.printStackTrace();
				return null;
				}
			}
		@TargetApi(Build.VERSION_CODES.FROYO)
		public XMLContent EncryptToContent(String pwd)
			{
			byte[] e = Encrypt(pwd);
			if (e == null)
				return null;
			
			// Base64
			
			String str = Base64.encodeToString(e, Base64.DEFAULT);
			XMLContent y = new XMLContent(null,str,0);
			return y;
			}
		
		public XMLElement Decrypt(String pwd,byte[] enc)
			{
			try 
				{
				if (enc == null || pwd == null)
					return null;

				// SHA-1 the password
				MessageDigest sha = MessageDigest.getInstance("SHA-1");
				byte[] key = sha.digest(pwd.getBytes());
				key = Arrays.copyOf(key, 32); // use only first 128 bit
				
				SecretKeySpec sks = new SecretKeySpec(key, "AES");
				
				 // Instantiate the cipher
			    Cipher cipher = Cipher.getInstance("AES");
			    cipher.init(Cipher.DECRYPT_MODE, sks);

				
			    byte[] decrypted = cipher.doFinal(enc);
			    if (decrypted == null)
			    	return null;
			    
			    String de = new String(decrypted);
			    XML xu = new XML(de);
			    XMLElement e = xu.GetRootElement();
			    return e;
				}
			catch(Throwable ex)
				{
				ex.printStackTrace();
				return null;
				}
			}

		@TargetApi(Build.VERSION_CODES.FROYO)
		public XMLElement DecryptFromContent(String pwd)
			{
			if (pwd == null)
				return null;
			
			if (Contents.isEmpty())
				return null;
			
			String s = Contents.get(0).GetValue();
			byte[] enc = Base64.decode(s, Base64.DEFAULT);
			return Decrypt(pwd,enc);
			}
		
		}
	
	
	static public class XMLContent
		{
		private String value = null;
		private XMLElement Parent = null;
		private int BeforeElement = 0;
		
		XMLContent Duplicate()
			{
			XMLContent x = new XMLContent(null,new String(value),BeforeElement);
			return x;
			}
	

		public int GetBE()
			{
			return BeforeElement;
			}
		public XMLContent(XMLElement p,String v,int be)
			{
			BeforeElement = be;
			Parent = p;
			value = v;
			}
		
	

		public String GetValue() 
			{
			return new String(value);
			}
		XMLElement GetParent()
			{
			return Parent;
			}
		String Serialize()
			{
			String s = String.format("%s",XML.XMLEncode(value));
			return s;
			}
		
		}
	static public class XMLComment
		{
		private String value = null;
		private XMLElement Parent = null;
		private int BeforeElement = 0;

		XMLComment Duplicate()
			{
			XMLComment x = new XMLComment(null,new String(value),BeforeElement);
			return x;
			}
	
		public int GetBE()
			{
			return BeforeElement;
			}
		public XMLComment(XMLElement p,String v,int be)
			{
			BeforeElement = be;
			Parent = p;
			value = v;
			}
		public String GetValue() 
			{
			return new String(value);
			}
		XMLElement GetParent()
			{
			return Parent;
			}
		String Serialize()
			{
			String s = String.format("<!-- %s -->",value);
			return s;
			}
		
		}
	static public class XMLCData
		{
		private String value = null;
		private XMLElement Parent = null;
		private int BeforeElement = 0;
		
		XMLCData Duplicate()
			{
			XMLCData x = new XMLCData(null,new String(value),BeforeElement);
			return x;
			}

		public int GetBE()
			{
			return BeforeElement;
			}
		public XMLCData(XMLElement p,String v,int be)
			{
			BeforeElement = be;
			Parent = p;
			value = v;
			}
		public String GetValue() 
			{
			return new String(value);
			}
		XMLElement GetParent()
			{
			return Parent;
			}
		String Serialize()
			{
			String s = String.format("<![CDATA[%s]]>",value);
			return s;
			}
		
		}
	
	static public class XMLVariable
		{
		private String name;
		private String value;
		private XMLElement Parent = null;
		
		
		XMLVariable Duplicate()
			{
			XMLVariable x = new XMLVariable(null,new String(name),new String(value));
			return x;
			}
		
		public int GetValueInt()
			{
			return XML.iv(GetValue());
			}
		public long GetValueLong()
			{
			return XML.lv(GetValue());
			}

		public void SetValueInt(int k)
			{
			SetValue(String.format("%d",k));
			}
		
		public XMLVariable(XMLElement p)
			{
			Parent = p;
			name = new String("");
			value = new String("");
			}
		public XMLVariable(XMLElement p,String n,String v)
			{
			Parent = p;
			name = new String(n);
			value = new String(v);
			}
		String Serialize()
			{
			String s = String.format("%s=\"%s\"",name,XML.XMLEncode(value));
			return s;
			}
		
		public String GetName() 
			{
			return new String(name);
			}
		public String GetValue() 
			{
			return new String(value);
			}
		public void SetName(String s) 
			{
			name = new String(s);
			}
		public void SetValue(String s) 
			{
			value = new String(s);
			}
		XMLElement GetParent()
			{
			return Parent;
			}
		}
	
	
	private void Parse()
		{
		try 
			{
			XmlPullParserFactory pf = XmlPullParserFactory.newInstance();
			XmlPullParser pp = pf.newPullParser();
			pp.setInput(wf, null);
//			pp.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
//			pp.setFeature(XmlPullParser.FEATURE_REPORT_NAMESPACE_ATTRIBUTES, false);
			
			int event = pp.next();
			
			XMLElement CurrentParent = null;
			
			for (; ; event = pp.next()) 
				{
				if (event == XmlPullParser.END_DOCUMENT)
					break; // End !

				if (event == XmlPullParser.END_TAG)
					{
					if (CurrentParent != root && CurrentParent != null) // Root
						{
						XMLElement e = CurrentParent.GetParent();
						CurrentParent = e;
						}
					}
				
				if (event == XmlPullParser.START_TAG)
					{
					if (CurrentParent == null) // Root
						{
						CurrentParent = root;
						}
					else
						{
						XMLElement e = new XMLElement(CurrentParent);
						CurrentParent.Children.add(e);
						CurrentParent = e;
						}
					
					String ElName = pp.getName();
					CurrentParent.SetName(ElName);
					
					// Variables
					int vc = pp.getAttributeCount();
					CurrentParent.Variables.clear();
					for(int i = 0 ; i < vc ; i++)
						{
						String n = pp.getAttributeName(i);
						String v = pp.getAttributeValue(i);
						XMLVariable xu = new XMLVariable(CurrentParent,n,v);
						CurrentParent.Variables.add(xu);
						}
					}
				
				if (event == XmlPullParser.COMMENT)
					{
					String t = pp.getText().trim();
					if (t != null && t.length() != 0)
						{
						XMLComment c = new XMLComment(CurrentParent,t,CurrentParent.GetChildren().size());
						CurrentParent.Comments.add(c);
						}
					}
				
				if (event == XmlPullParser.CDSECT)
					{
					String t = pp.getText().trim();
					if (t != null && t.length() != 0)
						{
						XMLCData c = new XMLCData(CurrentParent,t,CurrentParent.GetChildren().size());
						CurrentParent.CDatas.add(c);
						}
					}
				
				if (event == XmlPullParser.TEXT)
					{
					String t = pp.getText().trim();
					if (t != null && t.length() != 0)
						{
						XMLContent c = new XMLContent(CurrentParent,pp.getText(),CurrentParent.GetChildren().size());
						CurrentParent.Contents.add(c);
						}
					}
				
				}
			}
		catch(Throwable ex)
			{
			ex.printStackTrace();
			}
		}
	
	

}
